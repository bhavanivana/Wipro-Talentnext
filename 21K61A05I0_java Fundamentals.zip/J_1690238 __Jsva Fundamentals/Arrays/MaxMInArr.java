
public class MaxMInArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,3,4,2,6};
		int max=0,min=arr[0];
		for(int i =0;i<5;i++) {
			if(min>arr[i]) {
				min=arr[i];
			}
			if(max<arr[i]) {
				max=arr[i];
			}
		}
		System.out.println("Max value in array : "+max);
		System.out.println("Min Value in array : "+min);

	}

}
