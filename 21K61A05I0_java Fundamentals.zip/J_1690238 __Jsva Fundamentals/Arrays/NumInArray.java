import java.util.*;
public class NumInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		boolean isnum=false;
		int[] arr = {23,76,5,4,9,8,7};
		System.out.println("Enter a number to search :");
		int n= sc.nextInt();
		for(int i=0;i<7;i++) {
			if(n==arr[i]) {
				isnum=true;
				System.out.println("Index of a number is : "+i );
			}
			
		}
		if(!isnum)
		System.out.println(-1);
		

	}

}
