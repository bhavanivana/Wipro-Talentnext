import java.util.*;
public class DupArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stud
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of an array :");
		int n= sc.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter Elements in the array :");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();		}
		
        int[] temp = new int[n];
        int j = 0;

        for (int i = 0; i < n; i++) {
            boolean isDuplicate = false;
            for (int k = 0; k < j; k++) {
                if (arr[i] == temp[k]) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) {
                temp[j++] = arr[i];
            }
        }

        // Copy the unique elements back to the original array
        int[] result = Arrays.copyOf(temp, j);

        // Print the result
        System.out.println(Arrays.toString(result));
	}
	

}
