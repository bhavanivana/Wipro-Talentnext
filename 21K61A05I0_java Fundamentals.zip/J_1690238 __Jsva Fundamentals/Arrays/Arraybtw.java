import java.util.Scanner;
public class Arraybtw {
	static void conditionalSum(int arr[],int a,int b) {
		int sum=0;
		boolean add =true;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]!=a && add==true)
				sum=sum+arr[i];
			else if(arr[i] == a)
				add=false;
			else if(arr[i]==b)
				add=true;
		}
		System.out.println(sum);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of an array : ");
		int n= sc.nextInt();
		int a=6,b=7;
		int[] arr =new int[n];
		System.out.println("Enter element : ");
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		conditionalSum(arr,a,b);
		

	}

}
