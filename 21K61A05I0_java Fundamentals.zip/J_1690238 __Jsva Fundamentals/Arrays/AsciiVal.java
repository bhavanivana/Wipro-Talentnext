
public class AsciiVal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {66,78,100,54,56,76};
		char ch;
		for(int i=0;i<6;i++) {
			ch=(char)arr[i];
			System.out.print(ch +"   ");
		}

	}

}
