
public class SortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,33,2,43,41,90,0,7};
		int temp=0;
		for(int i =0;i<7;i++) {
			for(int j=i+1;j<8;j++) {
			
				if(arr[i]>arr[j]) {
				
					temp=arr[i];
				
					arr[i]=arr[j];
				
					arr[j]=temp;
			}
		}
		}
		System.out.println("After sorted array will be : ");
		for(int k=0;k<8;k++) {
			System.out.print(arr[k]+" ");	
			}

	}


}
