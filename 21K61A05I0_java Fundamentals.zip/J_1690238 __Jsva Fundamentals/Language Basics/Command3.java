
/**
 * 
 */
public class Command3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int t1 =Integer.parseInt(args[0]);
		int t2 = Integer.parseInt(args[1]);
		
		System.out.println(t1+t2);

	}

}
