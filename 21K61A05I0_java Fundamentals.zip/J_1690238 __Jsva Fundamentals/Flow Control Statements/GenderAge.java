
public class GenderAge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = Integer.parseInt(args[1]);
		if(args[0].equals("Female") && age <= 58) {
			System.out.println("8.2%");
		}
		else if(args[0].equals("Female") && age>=59) {
			System.out.println("9.2%");
		}
		else if(args[0].equals("Male") && age<=58) {
			System.out.println("8.4%");
		}
		else {
			System.out.println("10.5%");
		}

	}

}
