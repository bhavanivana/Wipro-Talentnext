import java.util.Scanner;
public class AlphaOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter two character : ");
		Scanner sc = new Scanner(System.in);
		String s1 = sc.next();
		String s2 = sc.next();
		if(s1.compareTo(s2)<0) {
			System.out.println(s1 +","+s2);
		}
		else {
			System.out.println(s2 +","+s1);
		}
			

	}
		

}
