import java.util.Scanner;
public class CharType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Character : ");
		String  s = sc.next();
		char ch = s.charAt(0);
		if(Character.isLetter(ch)) {
			System.out.println("Alphabet");
			
		}
		else if(Character.isDigit(ch)) {
			System.out.println("Number");
		}
		else {
			System.out.println("Special Character");
		}

	}

}
