import java.util.Scanner;
public class LastDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers : ");
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		int d1 = n1%10;
		int d2 = n2%2;
		if(d1 == d2) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
	}

}
