import java.util.*;
public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		boolean ispalin = true;
		String s = Integer.toString(n);
		int l=0,r=s.length()-1;
		while(l<r) {
			if(s.charAt(l)!=s.charAt(r)) {
				ispalin = false;
				break;
			}
			l++;
			r--;
		}
		if(ispalin)
		System.out.println("Palindrome");
		else
			System.out.println("Not a palindrome");
	}

}
