import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a num : ");
		int n=sc.nextInt();
		boolean ch = false;
		for(int i=2;i<Math.sqrt(i);i++) {
			if(n%i !=0 && i!=n) {
				ch= true;
			}
		}
		if(ch) {
			System.out.println("Prime NUmber");
		}
		else {
			System.out.println("Not a Prime Number");
		}

	}

}
