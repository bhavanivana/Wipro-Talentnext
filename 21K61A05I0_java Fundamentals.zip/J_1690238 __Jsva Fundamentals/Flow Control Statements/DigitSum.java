import java.util.*;
public class DigitSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int num= sc.nextInt();
		int sum=0;
		while(num>1) {
			sum += num%10;
			num = num/10;
		}
		sum+=num;
		System.out.println("Sum of the number : "+sum);
		

	}

}
