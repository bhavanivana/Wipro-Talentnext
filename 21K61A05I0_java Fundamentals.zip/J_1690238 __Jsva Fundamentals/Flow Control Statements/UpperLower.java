import java.util.Scanner;
public class UpperLower {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a character");
		Scanner sc = new Scanner(System.in);
		String s =sc.next();
		char s1 = s.charAt(0);
		
		if(Character.isUpperCase(s1)) {
			char s2 = Character.toLowerCase(s1);
			System.out.println(s2);
		}
		else {
			char s2 =Character.toUpperCase(s1);
			System.out.println(s2);
			
		}
		

	}

}
