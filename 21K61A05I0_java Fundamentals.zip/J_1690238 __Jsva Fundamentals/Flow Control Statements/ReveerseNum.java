import java.util.*;
public class ReveerseNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		int digit = 0;
		while(n>=0) {
			digit=n%10;
			System.out.print(digit);
			n = n/10;
		}

	}

}
